def check_age():
  while True:
    try:
      age = int(input("Enter your age: "))
      if age >= 18:
        print("You are eligible to drink.")
      else:
        print("You are not eligible to drink.")
      break
    except ValueError:
      print("Invalid input. Please enter a number for your age.")

check_age()
